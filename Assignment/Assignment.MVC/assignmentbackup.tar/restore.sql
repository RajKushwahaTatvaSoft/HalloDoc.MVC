--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 16.1
-- Dumped by pg_dump version 16.1

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE "AssignmentHMS";
--
-- Name: AssignmentHMS; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE "AssignmentHMS" WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'English_India.1252';


ALTER DATABASE "AssignmentHMS" OWNER TO postgres;

\connect "AssignmentHMS"

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: Doctor; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Doctor" (
    "DoctorId" integer NOT NULL,
    "Specialist" character varying(50) NOT NULL
);


ALTER TABLE public."Doctor" OWNER TO postgres;

--
-- Name: Doctor_DoctorId_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Doctor_DoctorId_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Doctor_DoctorId_seq" OWNER TO postgres;

--
-- Name: Doctor_DoctorId_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Doctor_DoctorId_seq" OWNED BY public."Doctor"."DoctorId";


--
-- Name: Patient; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Patient" (
    "PatientId" integer NOT NULL,
    "FirstName" character varying(100) NOT NULL,
    "LastName" character varying(100) NOT NULL,
    "DoctorId" integer NOT NULL,
    "Age" integer NOT NULL,
    "Email" character varying(50) NOT NULL,
    "PhoneNo" character varying(50) NOT NULL,
    "Gender" character varying(50) NOT NULL,
    "Disease" character varying(100) NOT NULL,
    "Specialist" character varying(50) NOT NULL
);


ALTER TABLE public."Patient" OWNER TO postgres;

--
-- Name: Patient_PatientId_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Patient_PatientId_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Patient_PatientId_seq" OWNER TO postgres;

--
-- Name: Patient_PatientId_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Patient_PatientId_seq" OWNED BY public."Patient"."PatientId";


--
-- Name: Doctor DoctorId; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Doctor" ALTER COLUMN "DoctorId" SET DEFAULT nextval('public."Doctor_DoctorId_seq"'::regclass);


--
-- Name: Patient PatientId; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Patient" ALTER COLUMN "PatientId" SET DEFAULT nextval('public."Patient_PatientId_seq"'::regclass);


--
-- Data for Name: Doctor; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Doctor" ("DoctorId", "Specialist") FROM stdin;
\.
COPY public."Doctor" ("DoctorId", "Specialist") FROM '$$PATH$$/4845.dat';

--
-- Data for Name: Patient; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Patient" ("PatientId", "FirstName", "LastName", "DoctorId", "Age", "Email", "PhoneNo", "Gender", "Disease", "Specialist") FROM stdin;
\.
COPY public."Patient" ("PatientId", "FirstName", "LastName", "DoctorId", "Age", "Email", "PhoneNo", "Gender", "Disease", "Specialist") FROM '$$PATH$$/4847.dat';

--
-- Name: Doctor_DoctorId_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Doctor_DoctorId_seq"', 1, true);


--
-- Name: Patient_PatientId_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Patient_PatientId_seq"', 10, true);


--
-- Name: Doctor Doctor_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Doctor"
    ADD CONSTRAINT "Doctor_pkey" PRIMARY KEY ("DoctorId");


--
-- Name: Patient Patient_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Patient"
    ADD CONSTRAINT "Patient_pkey" PRIMARY KEY ("PatientId");


--
-- Name: Patient Patient_DoctorId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Patient"
    ADD CONSTRAINT "Patient_DoctorId_fkey" FOREIGN KEY ("DoctorId") REFERENCES public."Doctor"("DoctorId");


--
-- PostgreSQL database dump complete
--

